export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCy-RPI6xWNM-3dtdSVp_UJYyROqvul3JU",
    authDomain: "roanuz-cricket-app-6ca9e.firebaseapp.com",
    databaseURL: "https://roanuz-cricket-app-6ca9e.firebaseio.com",
    projectId: "roanuz-cricket-app-6ca9e",
    storageBucket: "roanuz-cricket-app-6ca9e.appspot.com",
    messagingSenderId: "899661209798",
    appId: "1:899661209798:web:69a485b25bce019ad177c7",
    measurementId: "G-ZC1EGQ1FQD"
  },
  cricket_api: {
    access_key: "a18bb2ff101146a710b65800f171becd",
    secret_key: "b9af45d03bbfb50a648139bbbc320645",
    app_id: "com.prodevlivescore.www",
    device_id: "developer"
  }
};
